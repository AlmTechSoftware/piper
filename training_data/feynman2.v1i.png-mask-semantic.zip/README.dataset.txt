# feynman2 > 2023-07-13 9:39pm
https://universe.roboflow.com/almqv/feynman2

Provided by a Roboflow user
License: CC BY 4.0

