# FeynMAN > 2023-08-14 10:40pm
https://universe.roboflow.com/almqv/feynman

Provided by a Roboflow user
License: CC BY 4.0

