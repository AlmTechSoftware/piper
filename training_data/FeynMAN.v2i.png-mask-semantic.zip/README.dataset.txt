# FeynMAN > 2023-07-20 10:07pm
https://universe.roboflow.com/almqv/feynman

Provided by a Roboflow user
License: CC BY 4.0

