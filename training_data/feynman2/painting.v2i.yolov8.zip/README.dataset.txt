# painting > 2023-04-27 6:45pm
https://universe.roboflow.com/gachon-su2hj/painting-oyuev

Provided by a Roboflow user
License: CC BY 4.0

